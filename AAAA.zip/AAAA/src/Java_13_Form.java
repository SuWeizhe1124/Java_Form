import java.awt.Color;
import java.awt.Frame;

public class Java_13_Form {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Frame frm = new Frame("Form"); //標題
	        frm.setBackground(Color.yellow); //背景顏色
	        frm.setSize(500,500); //標單寬度,長度
	        frm.setVisible(true); //顯示表單
	}

}
